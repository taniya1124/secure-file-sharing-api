# 🔐 Secure File Sharing API

A FastAPI-based backend for secure file sharing between Ops and Client users.

## 🚀 Features
- Signup/Login with JWT
- Upload files (Ops only)
- Encrypted download links (Client)
- Swagger UI for testing

## 💻 Setup
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Access docs at: http://127.0.0.1:8000/docs
